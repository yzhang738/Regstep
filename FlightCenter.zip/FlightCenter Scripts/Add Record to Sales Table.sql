INSERT INTO dbo.Sales(Name, UserID, Shop, CreatedDateTime, BookingDate, PassengerName, Destination, Deposit, SaleLocation, IsDeleted)
SELECT 'Flight', 'York', 'Bay', '2012-07-27', '2012-07-27', 'York', 'New York', '100.00', 'Vancouver', 0 
