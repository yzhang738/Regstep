﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlightCenterBusiness
{
    public static class Constant
    {
        public const int NumberSalesSupplier = 10;
    }
}
